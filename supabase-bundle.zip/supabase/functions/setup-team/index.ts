import { admin, publicAuth, json, preflight, normalizarNome, newPinCredential, authPassword, newOpaquePassword, newTeamCode, teamCodeHash } from "../_shared/server.ts";

function mesmoSegredo(a: string, b: string) {
  let diferenca = a.length ^ b.length;
  const tamanho = Math.max(a.length, b.length);
  for (let i = 0; i < tamanho; i++) diferenca |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return diferenca === 0;
}
Deno.serve(async request => {
  const options = preflight(request); if (options) return options;
  if (request.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const body = await request.json().catch(() => ({}));
  const setupToken = Deno.env.get("BOOTSTRAP_TOKEN") ?? "";
  if (!setupToken || !mesmoSegredo(String(body.setup_token ?? ""), setupToken)) return json({ error: "Código de configuração inválido." }, 401);
  const name = String(body.name ?? "").trim().replace(/\s+/g, " ");
  const teamName = String(body.team_name ?? "").trim();
  const recoveryEmail = String(body.recovery_email ?? "").trim().toLowerCase();
  const pin = String(body.pin ?? "");
  if (normalizarNome(name).length < 2 || teamName.length < 2 || !/^\S+@\S+\.\S+$/.test(recoveryEmail) || !/^\d{4}$/.test(pin)) {
    return json({ error: "Confira o nome, a equipe, o e-mail de recuperação e o PIN de quatro números." }, 400);
  }
  const { count, error: countError } = await admin.from("teams").select("id", { count: "exact", head: true });
  if (countError) return json({ error: "Não foi possível conferir a configuração inicial." }, 500);
  if ((count ?? 0) > 0) return json({ error: "A equipe principal já foi configurada." }, 409);
  const { error: claimError } = await admin.from("app_setup").insert({ id: true });
  if (claimError) return json({ error: "A configuração inicial já foi usada." }, 409);

  const teamId = crypto.randomUUID(), memberId = crypto.randomUUID();
  const code = newTeamCode();
  const credential = await newPinCredential(pin);
  const loginEmail = "pc-" + memberId + "@pc-login.invalid";
  const memberPassword = await authPassword(memberId, pin);
  const owner = await admin.auth.admin.createUser({
    email: loginEmail, password: memberPassword, email_confirm: true,
    app_metadata: { team_id: teamId, role: "principal", member_id: memberId },
    user_metadata: { name },
  });
  if (owner.error || !owner.data.user) {
    await admin.from("app_setup").delete().eq("id", true);
    return json({ error: "Não foi possível criar a conta principal." }, 500);
  }
  const ownerAuthId = owner.data.user.id;
  const recoveryUser = await admin.auth.admin.createUser({
    email: recoveryEmail, password: newOpaquePassword(), email_confirm: true,
    app_metadata: { team_id: teamId, role: "recovery" }, user_metadata: { name: "Recuperação da equipe" },
  });
  if (recoveryUser.error || !recoveryUser.data.user) {
    await admin.auth.admin.deleteUser(ownerAuthId);
    await admin.from("app_setup").delete().eq("id", true);
    return json({ error: "Não foi possível preparar o e-mail de recuperação." }, 500);
  }

  const { error: teamError } = await admin.from("teams").insert({ id: teamId, name: teamName, code_hash: await teamCodeHash(code) });
  const { error: memberError } = teamError ? { error: teamError } : await admin.from("team_members").insert({
    id: memberId, team_id: teamId, auth_user_id: ownerAuthId, name, role: "principal",
  });
  const { error: recoveryError } = memberError ? { error: memberError } : await admin.from("team_recovery").insert({
    team_id: teamId, recovery_email: recoveryEmail, recovery_auth_id: recoveryUser.data.user.id,
  });
  const { error: credentialError } = recoveryError ? { error: recoveryError } : await admin.from("member_credentials").insert({ member_id: memberId, ...credential });
  if (teamError || memberError || recoveryError || credentialError) {
    await admin.from("teams").delete().eq("id", teamId);
    await admin.from("app_setup").delete().eq("id", true);
    await admin.auth.admin.deleteUser(recoveryUser.data.user.id);
    await admin.auth.admin.deleteUser(ownerAuthId);
    return json({ error: "Não foi possível salvar a configuração da equipe." }, 500);
  }
  await admin.from("app_setup").update({ team_id: teamId }).eq("id", true);
  const { data: session, error: loginError } = await publicAuth.auth.signInWithPassword({ email: loginEmail, password: memberPassword });
  if (loginError || !session.session) return json({ error: "Equipe criada; entre novamente com o nome e PIN." }, 500);
  return json({ team_code: code, team_name: teamName, member: { id: memberId, name, role: "principal" }, session: session.session });
});

