import { admin, publicAuth, json, preflight, teamCodeHash } from "../_shared/server.ts";
Deno.serve(async request => {
  const options = preflight(request); if (options) return options;
  if (request.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const body = await request.json().catch(() => ({}));
  const code = String(body.team_code ?? "").trim().toUpperCase();
  const generic = { message: "Se a equipe estiver configurada, um link de recuperação será enviado ao e-mail da Conta 1." };
  if (code.length < 32) return json(generic);
  const { data: team } = await admin.from("teams").select("id").eq("code_hash", await teamCodeHash(code)).maybeSingle();
  if (!team) return json(generic);
  const { data: recovery } = await admin.from("team_recovery").select("recovery_email").eq("team_id", team.id).maybeSingle();
  if (!recovery?.recovery_email) return json(generic);
  const redirectTo = Deno.env.get("PUBLIC_APP_URL") ?? "https://felipeleans.github.io/pequenos-construtores/";
  await publicAuth.auth.resetPasswordForEmail(recovery.recovery_email, { redirectTo: redirectTo + "?recuperar-pin=1" });
  return json(generic);
});

