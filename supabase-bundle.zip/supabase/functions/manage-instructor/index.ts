import { admin, json, preflight, currentUser, normalizarNome, newPinCredential, authPassword } from "../_shared/server.ts";

Deno.serve(async request => {
  const options = preflight(request); if (options) return options;
  if (request.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const user = await currentUser(request);
  const meta = user?.app_metadata ?? {};
  if (!user || meta.role !== "principal" || !meta.team_id) return json({ error: "Somente a Conta principal pode gerenciar instrutores." }, 403);
  const body = await request.json().catch(() => ({}));
  const memberId = String(body.member_id ?? "");
  const action = String(body.action ?? "");
  if (!/^[0-9a-f-]{36}$/i.test(memberId) || !["editar", "remover"].includes(action)) return json({ error: "Ação ou instrutor inválido." }, 400);
  const { data: member, error: memberLookupError } = await admin.from("team_members")
    .select("id,team_id,auth_user_id,name,role,active")
    .eq("id", memberId).eq("team_id", meta.team_id).maybeSingle();
  if (memberLookupError || !member || member.role !== "instrutor" || !member.active) return json({ error: "Instrutor não encontrado ou já removido." }, 404);

  if (action === "remover") {
    const { error } = await admin.from("team_members").update({ active: false }).eq("id", memberId).eq("team_id", meta.team_id);
    if (error) return json({ error: "Não foi possível remover o acesso do instrutor." }, 500);
    await admin.auth.admin.deleteUser(member.auth_user_id);
    return json({ ok: true, member_id: memberId });
  }

  const name = String(body.name ?? "").trim().replace(/\s+/g, " ");
  const pin = body.pin == null || body.pin === "" ? "" : String(body.pin);
  if (normalizarNome(name).length < 2 || (pin && !/^\d{4}$/.test(pin))) return json({ error: "Confira o nome e o PIN de quatro números." }, 400);
  const { data: oldCredential, error: credentialLookupError } = await admin.from("member_credentials")
    .select("pin_salt,pin_hash").eq("member_id", memberId).maybeSingle();
  if (credentialLookupError || !oldCredential) return json({ error: "Não foi possível localizar as credenciais deste instrutor." }, 500);
  const credential = pin ? await newPinCredential(pin) : oldCredential;
  const { error: updateMemberError } = await admin.from("team_members").update({ name }).eq("id", memberId).eq("team_id", meta.team_id);
  if (updateMemberError) return json({ error: "Não foi possível atualizar o nome. Confira se ele já está em uso." }, 409);
  if (pin) {
    const { error: updateCredentialError } = await admin.from("member_credentials").update(credential).eq("member_id", memberId);
    if (updateCredentialError) {
      await admin.from("team_members").update({ name: member.name }).eq("id", memberId);
      return json({ error: "Não foi possível salvar o novo PIN." }, 500);
    }
  }
  const authUpdate = await admin.auth.admin.updateUserById(member.auth_user_id, {
    ...(pin ? { password: await authPassword(memberId, pin) } : {}),
    user_metadata: { name },
  });
  if (authUpdate.error) {
    await admin.from("team_members").update({ name: member.name }).eq("id", memberId);
    if (pin) await admin.from("member_credentials").update(oldCredential).eq("member_id", memberId);
    return json({ error: "Não foi possível atualizar as credenciais deste instrutor." }, 500);
  }
  return json({ member: { id: memberId, name, role: "instrutor" } });
});
