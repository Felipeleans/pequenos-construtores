import { admin, json, preflight, currentUser, normalizarNome, newPinCredential, authPassword } from "../_shared/server.ts";
Deno.serve(async request => {
  const options = preflight(request); if (options) return options;
  if (request.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const user = await currentUser(request);
  const meta = user?.app_metadata ?? {};
  if (!user || meta.role !== "principal" || !meta.team_id) return json({ error: "Somente a Conta 1 pode adicionar instrutores." }, 403);
  const body = await request.json().catch(() => ({}));
  const name = String(body.name ?? "").trim().replace(/\s+/g, " ");
  const pin = String(body.pin ?? "");
  if (normalizarNome(name).length < 2 || !/^\d{4}$/.test(pin)) return json({ error: "Confira o nome e o PIN de quatro números." }, 400);
  const id = crypto.randomUUID();
  const email = "pc-" + id + "@pc-login.invalid";
  const password = await authPassword(id, pin);
  const created = await admin.auth.admin.createUser({
    email, password, email_confirm: true,
    app_metadata: { team_id: meta.team_id, role: "instrutor", member_id: id },
    user_metadata: { name },
  });
  if (created.error || !created.data.user) return json({ error: "Não foi possível criar esse acesso." }, 400);
  const { error: memberError } = await admin.from("team_members").insert({
    id, team_id: meta.team_id, auth_user_id: created.data.user.id, name, role: "instrutor",
  });
  const credential = await newPinCredential(pin);
  const { error: credentialError } = memberError ? { error: memberError } : await admin.from("member_credentials").insert({ member_id: id, ...credential });
  if (memberError || credentialError) {
    await admin.from("team_members").delete().eq("id", id);
    await admin.auth.admin.deleteUser(created.data.user.id);
    return json({ error: "Não foi possível salvar o novo acesso. Verifique se o nome já existe." }, 400);
  }
  return json({ member: { id, name, role: "instrutor" } });
});

