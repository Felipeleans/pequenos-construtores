import { admin, publicAuth, json, preflight, normalizarNome, makePinHash, authPassword, teamCodeHash, rateLimit, clientIp } from "../_shared/server.ts";
Deno.serve(async request => {
  const options = preflight(request); if (options) return options;
  if (request.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const body = await request.json().catch(() => ({}));
  const code = String(body.team_code ?? "").trim().toUpperCase();
  const name = String(body.name ?? "").trim().replace(/\s+/g, " ");
  const normalized = normalizarNome(name);
  const pin = String(body.pin ?? "");
  if (code.length < 32 || normalized.length < 2 || !/^\d{4}$/.test(pin)) return json({ error: "Confira o código da equipe, o nome e o PIN." }, 400);
  const { data: team } = await admin.from("teams").select("id,name").eq("code_hash", await teamCodeHash(code)).maybeSingle();
  if (!team) return json({ error: "Código da equipe, nome ou PIN incorreto." }, 401);
  const ip = clientIp(request);
  const limits = await Promise.all([
    rateLimit(team.id + ":" + normalized + ":" + ip, null),
    rateLimit(team.id + ":ip:" + ip, null),
  ]);
  if (limits.some(item => !item.pode_tentar)) return json({ error: "Muitas tentativas. Aguarde 15 minutos antes de tentar novamente." }, 429);
  const { data: rows } = await admin.from("team_members").select("id,name,role,auth_user_id").eq("team_id", team.id).eq("active", true);
  const member = rows?.find(item => normalizarNome(item.name) === normalized);
  if (!member) {
    await rateLimit(team.id + ":" + normalized + ":" + ip, false);
    await rateLimit(team.id + ":ip:" + ip, false);
    return json({ error: "Código da equipe, nome ou PIN incorreto." }, 401);
  }
  const { data: credential } = await admin.from("member_credentials").select("pin_salt,pin_hash").eq("member_id", member.id).maybeSingle();
  const valid = !!credential && await makePinHash(pin, credential.pin_salt) === credential.pin_hash;
  if (!valid) {
    await rateLimit(team.id + ":" + normalized + ":" + ip, false);
    await rateLimit(team.id + ":ip:" + ip, false);
    return json({ error: "Código da equipe, nome ou PIN incorreto." }, 401);
  }
  await rateLimit(team.id + ":" + normalized + ":" + ip, true);
  await rateLimit(team.id + ":ip:" + ip, true);
  const loginEmail = "pc-" + member.id + "@pc-login.invalid";
  const password = await authPassword(member.id, pin);
  const { data, error } = await publicAuth.auth.signInWithPassword({ email: loginEmail, password });
  if (error || !data.session) return json({ error: "Não foi possível iniciar a sessão segura." }, 401);
  return json({ session: data.session, member: { id: member.id, name: member.name, role: member.role }, team: { id: team.id, name: team.name } });
});

