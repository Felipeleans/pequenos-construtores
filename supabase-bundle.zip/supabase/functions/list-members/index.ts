import { admin, json, preflight, teamCodeHash } from "../_shared/server.ts";
Deno.serve(async request => {
  const options = preflight(request); if (options) return options;
  if (request.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const body = await request.json().catch(() => ({}));
  const code = String(body.team_code ?? "").trim().toUpperCase();
  if (code.length < 32) return json({ error: "Código da equipe inválido." }, 400);
  const { data: team } = await admin.from("teams").select("id,name").eq("code_hash", await teamCodeHash(code)).maybeSingle();
  if (!team) return json({ error: "Equipe não encontrada." }, 404);
  const { data: members, error } = await admin.from("team_members").select("id,name,role").eq("team_id", team.id).eq("active", true).order("name");
  if (error) return json({ error: "Não foi possível carregar os nomes." }, 500);
  return json({ team: { name: team.name }, members: members ?? [] });
});

