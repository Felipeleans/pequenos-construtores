import { admin, json, preflight, currentUser, newPinCredential, authPassword } from "../_shared/server.ts";
Deno.serve(async request => {
  const options = preflight(request); if (options) return options;
  if (request.method !== "POST") return json({ error: "Método não permitido." }, 405);
  const user = await currentUser(request);
  const meta = user?.app_metadata ?? {};
  if (!user || meta.role !== "recovery" || !meta.team_id) return json({ error: "Abra o link recebido no e-mail da Conta 1 para redefinir PINs." }, 403);
  const body = await request.json().catch(() => ({}));
  const memberId = String(body.member_id ?? "");
  const pin = String(body.pin ?? "");
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(memberId) || !/^\d{4}$/.test(pin)) return json({ error: "Confira o instrutor e o novo PIN." }, 400);
  const { data: member } = await admin.from("team_members").select("id,team_id,auth_user_id").eq("id", memberId).eq("team_id", meta.team_id).eq("active", true).maybeSingle();
  if (!member) return json({ error: "Instrutor não encontrado nesta equipe." }, 404);
  const credential = await newPinCredential(pin);
  const { error: authError } = await admin.auth.admin.updateUserById(member.auth_user_id, { password: await authPassword(member.id, pin) });
  if (authError) return json({ error: "Não foi possível redefinir o PIN." }, 500);
  const { error } = await admin.from("member_credentials").upsert({ member_id: member.id, ...credential, updated_at: new Date().toISOString() });
  if (error) return json({ error: "O PIN foi atualizado, mas houve um erro ao salvar a verificação. Fale com a Conta 1." }, 500);
  return json({ message: "PIN redefinido. O instrutor já pode entrar com o novo PIN." });
});

