import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";

const url = Deno.env.get("SUPABASE_URL") ?? "";
function defaultKey(name: string) {
  try { const keys = JSON.parse(Deno.env.get(name) ?? "{}"); return keys.default ?? Object.values(keys)[0] ?? ""; }
  catch { return ""; }
}
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? defaultKey("SUPABASE_SECRET_KEYS");
const publicKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? defaultKey("SUPABASE_PUBLISHABLE_KEYS");
export const pepper = Deno.env.get("PIN_PEPPER") ?? "";
export const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
export const publicAuth = createClient(url, publicKey, { auth: { persistSession: false, autoRefreshToken: false } });

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
export function preflight(request: Request) {
  return request.method === "OPTIONS" ? new Response("ok", { headers: corsHeaders }) : null;
}
export function normalizarNome(value: unknown) {
  return String(value ?? "").normalize("NFKC").trim().replace(/\s+/g, " ").toLocaleLowerCase("pt-BR");
}
export function bytesHex(bytes: Uint8Array) {
  return [...bytes].map(value => value.toString(16).padStart(2, "0")).join("");
}
export async function sha256(value: string) {
  return bytesHex(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))));
}
export async function hmac(value: string) {
  if (!pepper || pepper.length < 32) throw new Error("PIN_PEPPER não configurado.");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pepper), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}
export function base64url(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
export async function authPassword(memberId: string, pin: string) {
  return base64url(await hmac("auth:" + memberId + ":" + pin));
}
export async function makePinHash(pin: string, salt: string) {
  const material = await hmac("pin:" + pin);
  const key = await crypto.subtle.importKey("raw", material, "PBKDF2", false, ["deriveBits"]);
  const saltBytes = Uint8Array.from(atob(salt), char => char.charCodeAt(0));
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: saltBytes, iterations: 310000, hash: "SHA-256" }, key, 256);
  return base64url(new Uint8Array(bits));
}
export async function newPinCredential(pin: string) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  let saltText = "";
  for (const byte of salt) saltText += String.fromCharCode(byte);
  saltText = btoa(saltText);
  return { pin_salt: btoa(String.fromCharCode(...salt)), pin_hash: await makePinHash(pin, saltText) };
}
export async function teamCodeHash(code: string) {
  return sha256(code.trim().toUpperCase());
}
export function newTeamCode() {
  return base64url(crypto.getRandomValues(new Uint8Array(24))).toUpperCase();
}
export function newOpaquePassword() {
  return base64url(crypto.getRandomValues(new Uint8Array(48))) + "A1!";
}
export function bearer(request: Request) {
  return request.headers.get("Authorization")?.replace(/^Bearer\s+/i, "") ?? "";
}
export async function currentUser(request: Request) {
  const token = bearer(request);
  if (!token) return null;
  const { data, error } = await admin.auth.getUser(token);
  return error ? null : data.user;
}
export async function rateLimit(identity: string, success: boolean | null) {
  const identityHash = bytesHex(await hmac("limit:" + identity));
  const { data, error } = await admin.rpc("registrar_tentativa_pin", { p_identity_hash: identityHash, p_sucesso: success });
  if (error) throw error;
  return data?.[0] ?? { pode_tentar: false, bloqueado_ate: null };
}
export function clientIp(request: Request) {
  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("cf-connecting-ip") || "unknown";
}

