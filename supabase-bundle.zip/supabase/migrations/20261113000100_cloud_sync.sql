-- Estrutura compartilhada do Pequenos Construtores, com isolamento por equipe.
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
grant usage on schema private to service_role, authenticated;

create table if not exists public.teams (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 100),
  code_hash text not null unique,
  created_at timestamptz not null default now()
);
create table if not exists public.app_setup (
  id boolean primary key default true check (id),
  team_id uuid unique references public.teams(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.team_members (
  id uuid primary key,
  team_id uuid not null references public.teams(id) on delete cascade,
  auth_user_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 70),
  role text not null check (role in ('principal', 'instrutor')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists team_members_unique_name on public.team_members(team_id, lower(name));
create table if not exists public.team_recovery (
  team_id uuid primary key references public.teams(id) on delete cascade,
  recovery_email text not null,
  recovery_auth_id uuid not null unique references auth.users(id) on delete cascade
);
create table if not exists public.member_credentials (
  member_id uuid primary key references public.team_members(id) on delete cascade,
  pin_salt text not null,
  pin_hash text not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.pin_login_limits (
  identity_hash text primary key,
  failed_attempts integer not null default 0,
  locked_until timestamptz,
  updated_at timestamptz not null default now()
);
create table if not exists public.sync_rows (
  team_id uuid not null references public.teams(id) on delete cascade,
  collection text not null check (collection in ('children', 'missions', 'records', 'bonus')),
  row_id text not null,
  content jsonb,
  deleted boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (team_id, collection, row_id)
);

alter table public.teams enable row level security;
alter table public.app_setup enable row level security;
alter table public.team_members enable row level security;
alter table public.team_recovery enable row level security;
alter table public.member_credentials enable row level security;
alter table public.pin_login_limits enable row level security;
alter table public.sync_rows enable row level security;

create or replace function private.current_team_id()
returns uuid language sql stable set search_path = ''
as $$ select nullif(auth.jwt() -> 'app_metadata' ->> 'team_id', '')::uuid $$;
create or replace function private.is_active_team_member()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.team_members m
    where m.auth_user_id = (select auth.uid())
      and m.team_id = private.current_team_id()
      and m.active
  )
$$;
create or replace function private.can_read_team_roster()
returns boolean language sql stable set search_path = ''
as $$
  select (auth.jwt() -> 'app_metadata' ->> 'role') = 'recovery'
    or (select private.is_active_team_member())
$$;
revoke all on function private.current_team_id() from public, anon;
revoke all on function private.is_active_team_member() from public, anon;
revoke all on function private.can_read_team_roster() from public, anon;
grant execute on function private.current_team_id() to authenticated;
grant execute on function private.is_active_team_member() to authenticated;
grant execute on function private.can_read_team_roster() to authenticated;

create policy "members read their team" on public.teams for select to authenticated
  using (id = (select private.current_team_id()) and (select private.is_active_team_member()));
create policy "members read roster" on public.team_members for select to authenticated
  using (team_id = (select private.current_team_id()) and (select private.can_read_team_roster()));
create policy "members read team data" on public.sync_rows for select to authenticated
  using (team_id = (select private.current_team_id()) and (select private.is_active_team_member()));
create policy "members add team data" on public.sync_rows for insert to authenticated
  with check (team_id = (select private.current_team_id()) and (select private.is_active_team_member()));
create policy "members update team data" on public.sync_rows for update to authenticated
  using (team_id = (select private.current_team_id()) and (select private.is_active_team_member()))
  with check (team_id = (select private.current_team_id()) and (select private.is_active_team_member()));

revoke all on public.teams, public.app_setup, public.team_members, public.team_recovery,
  public.member_credentials, public.pin_login_limits, public.sync_rows from public, anon, authenticated;
grant select on public.teams, public.team_members to authenticated;
grant select, insert, update on public.sync_rows to authenticated;
grant select, insert, update, delete on public.teams, public.app_setup, public.team_members,
  public.team_recovery, public.member_credentials, public.pin_login_limits, public.sync_rows to service_role;

create or replace function public.registrar_tentativa_pin(p_identity_hash text, p_sucesso boolean)
returns table(pode_tentar boolean, bloqueado_ate timestamptz)
language plpgsql security definer set search_path = ''
as $$
declare v public.pin_login_limits%rowtype;
begin
  insert into public.pin_login_limits(identity_hash) values (p_identity_hash)
    on conflict (identity_hash) do nothing;
  select * into v from public.pin_login_limits where identity_hash = p_identity_hash for update;
  if v.locked_until is not null and v.locked_until > now() then
    return query select false, v.locked_until; return;
  end if;
  if p_sucesso is null then return query select true, null::timestamptz; return; end if;
  if p_sucesso then
    delete from public.pin_login_limits where identity_hash = p_identity_hash;
    return query select true, null::timestamptz; return;
  end if;
  update public.pin_login_limits
    set failed_attempts = case when updated_at < now() - interval '15 minutes' then 1 else failed_attempts + 1 end,
        locked_until = case when (case when updated_at < now() - interval '15 minutes' then 1 else failed_attempts + 1 end) >= 5
          then now() + interval '15 minutes' else null end,
        updated_at = now()
    where identity_hash = p_identity_hash returning * into v;
  return query select v.locked_until is null, v.locked_until;
end;
$$;
revoke all on function public.registrar_tentativa_pin(text, boolean) from public, anon, authenticated;
grant execute on function public.registrar_tentativa_pin(text, boolean) to service_role;
